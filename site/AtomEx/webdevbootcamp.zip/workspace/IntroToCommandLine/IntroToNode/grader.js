function average(scores) {
    //add all scores together
    var total = 0;
    scores.forEach(function(score) {
        total += score;
    })
    //divide by the total number of scores
    var avg = total/scores.length;
    
    //round avg
    return Math.round(avg);
    
}

var scores = [90, 98, 100, 100, 86, 94];
console.log(average(scores)); 