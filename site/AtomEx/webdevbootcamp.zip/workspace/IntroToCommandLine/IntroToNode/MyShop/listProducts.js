var faker = require('faker');

// var randProduct = faker.commerce.product(); 
// var randPrice = faker.commerce.price();


for (var i = 0; i < 10; i++) {
    var randProduct = faker.commerce.productName(); 
    var randPrice = faker.commerce.price();
    console.log(randProduct + " - $" + randPrice);
}
