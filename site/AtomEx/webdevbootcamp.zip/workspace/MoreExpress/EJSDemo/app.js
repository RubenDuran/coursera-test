var express = require("express");
var app = express();


app.get("/", function(req, res) {
    res.render("home.ejs");
    //res.send("Welcome to the home page!");
});


app.get("/posts", function(req, res) {
    var posts = [
        {title: "Post1", author: "Susy"},
        {title: "Post2", author: "Tim"},
        {title: "Post3", author: "David"}
    ]
    res.render("posts.ejs", {posts: posts});
});


app.get("/fallinlovewith/:thing", function(req, res) {
    var thing = req.params.thing;
    res.render("love.ejs", {thingVar: thing});
});



app.listen(process.env.PORT, process.env.IP, function() {
    console.log("server is listening!!!");
});